# Internal defence package contents

This archive contains internal-defence documentation, corrected tables and figures, the PyBullet demonstration and its model exports, the unchanged recovered Colab archive, and selected source evidence. It excludes virtual environments, caches, and raw industrial datasets.
