# Local PyBullet demonstration

The demonstration reuses the V1.1 KUKA environment and the recovered model weights. It executes one scenario per command. A demonstration is illustrative; it is not a substitute for the 50-seed evaluation.

## Prepare

From the repository root, run:

```powershell
& .\.conda-training\python.exe -m experiments.v1_1.export_defence_models
```

This creates separate model copies in `DEFENCE_2026\models`. It does not overwrite `models\teacher.pt` or historical result files. It also rebuilds dynamic-batch ONNX files and runs checker/runtime parity tests. Current outcomes are recorded in `DEFENCE_2026\models\model_provenance.json`.

## Run the live GUI

```powershell
& .\.conda-training\python.exe .\defence_demo.py --controller student_improved --seed 140000
```

Available choices are `ik`, `teacher_original`, `student_original`, and `student_improved`. Use the same `--seed` for a matched visual scenario:

```powershell
& .\.conda-training\python.exe .\defence_demo.py --controller ik --seed 140000
& .\.conda-training\python.exe .\defence_demo.py --controller teacher_original --seed 140000
& .\.conda-training\python.exe .\defence_demo.py --controller student_original --seed 140000
& .\.conda-training\python.exe .\defence_demo.py --controller student_improved --seed 140000
```

Choose any integer seed with `--seed`. The GUI shows target/HUD information and the console logs controller, phase, target, completion, simulated time, energy, peak power, and parameter count. Runs append to `DEFENCE_2026\demo_runs.csv`.

## Headless verification

```powershell
& .\.conda-training\python.exe .\defence_demo.py --controller student_improved --seed 140000 --headless --max-steps 20
```

The demonstration reports simulated mechanical-work energy, not measured electrical consumption. Do not present a single run's outcome as the overall evaluation result.

## Verification record

The live GUI path was run for the selected student on seed 140000. It completed that one scenario in 169 steps (0.704 simulated seconds), with 195.34 J simulated grid energy and 874.18 W peak simulated power. These values are in `demo_runs.csv`; they are one demonstration episode and are not the 50-scenario result. The four-controller headless comparison is in `demo_headless_verification.csv`.
