# Package status

This archive contains verified historical results and local V1.1 smoke evidence as of 2026-11-26. It is a preparation package, **not** the completed V1.1 research run. The notebook still needs to run in Colab in deadline or full mode before fresh performance claims can be added. The local smoke output is deliberately labelled smoke and must not be presented as research results.
